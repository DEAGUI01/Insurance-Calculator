﻿//Daniel Aguilar            CIS 199-01          Lab 4           10/16/2022          Grading ID: K7209 


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program_2
{
    public partial class InsurancePolicyCalculator : Form
    {
        public InsurancePolicyCalculator()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void InsurancePolicyCalculator_Load(object sender, EventArgs e)
        {

        }

        private void SmokeGroupBox_Enter(object sender, EventArgs e)
        {

        }

        private void SmokeLabel_Click(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void TotalPolicyCostLabel_Click(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void label1_Click_2(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged_1(object sender, EventArgs e)
        {

        }

        private void label1_Click_3(object sender, EventArgs e)
        {

        }

        private void label1_Click_4(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //constants
            const double epoRate = 100;
            const double ppoRate = 75;
            const double hdpRate = 25;
            const double fullRate = 115;
            const double liabilityRate = 60;
            const double smokingFee = 30;
            const double accidentRate = 0.3;
            const double youngFee = 10;
            const double modernCarFee = 15;
            const int year = 12;

            //global variables
            int clientAge;
            int carYear;
            double monthlyHealthCoverageCost = 0;
            double montlyCarCoverageCost = 0;
            double yearlyHealthCoverageCost;
            double yearlyCarCoverageCost;
            double yearlyPolicyTotal;


            if (int.TryParse(AgeInputBox.Text, out clientAge) && (clientAge >= 18 && clientAge <= 100)) //validates client age
            {
                if (int.TryParse(ManufactureYearInputBox.Text, out carYear) && (carYear >= 1960 && carYear <= 2022)) //validates car manufacture year
                {
                    if (HealthInsuranceComboBox.SelectedIndex == -1) //validates response for health insurance
                    {
                        MessageBox.Show("No option selected for Health Insurance"); 
                    }
                    else
                    {
                        if (CarInsuranceComboBox.SelectedIndex == -1) //validates response for car insurance
                        {
                            MessageBox.Show("No option selected for Car Insurance");
                        }
                        else
                        {
                            if(SmokeNoButton.Checked == false && SmokeYesButton.Checked == false) //validates response for smoking
                            {
                                MessageBox.Show("No response selected for smoking");
                            }
                            else
                            {
                                if(CarAccidentNoButton.Checked == false && CarAccidentYesButton.Checked == false) //validates response for car accident
                                {
                                    MessageBox.Show("No response selected for car accident");
                                }
                                else
                                //health insurance
                                {
                                    if ((HealthInsuranceComboBox.SelectedIndex == 0) && (SmokeYesButton.Checked == true))
                                    {
                                        monthlyHealthCoverageCost = epoRate + smokingFee;
                                    }
                                    else if ((HealthInsuranceComboBox.SelectedIndex == 0) && (SmokeNoButton.Checked == true))
                                    {
                                        monthlyHealthCoverageCost = epoRate;
                                    }
                                    else if ((HealthInsuranceComboBox.SelectedIndex == 1) && (SmokeYesButton.Checked == true))
                                    {
                                        monthlyHealthCoverageCost = ppoRate + smokingFee;
                                    }
                                    else if ((HealthInsuranceComboBox.SelectedIndex == 1) && (SmokeNoButton.Checked == true))
                                    {
                                        monthlyHealthCoverageCost = ppoRate;
                                    }
                                    else if ((HealthInsuranceComboBox.SelectedIndex == 2) && (SmokeYesButton.Checked == true))
                                    {
                                        monthlyHealthCoverageCost = hdpRate + smokingFee;
                                    }
                                    else if ((HealthInsuranceComboBox.SelectedIndex == 2) && (SmokeNoButton.Checked == true))
                                    {
                                        monthlyHealthCoverageCost = hdpRate;
                                    }
                                    else if (HealthInsuranceComboBox.SelectedIndex == 3)
                                        {
                                        monthlyHealthCoverageCost = 0;
                                    }
                                    //liability
                                    if ((CarInsuranceComboBox.SelectedIndex == 0) && (CarAccidentYesButton.Checked == true) && (clientAge < 25) && (carYear > 2012)) //young with accident and modern car
                                    {
                                        montlyCarCoverageCost = liabilityRate + (liabilityRate * accidentRate) + youngFee + modernCarFee;
                                    }
                                    else if ((CarInsuranceComboBox.SelectedIndex == 0) && (CarAccidentNoButton.Checked == true) && (clientAge < 25) && (carYear > 2012)) //young with modern car
                                    {
                                        montlyCarCoverageCost = liabilityRate + youngFee + modernCarFee;
                                    }
                                    else if ((CarInsuranceComboBox.SelectedIndex == 0) && (CarAccidentYesButton.Checked == true) && (clientAge > 25) && (carYear > 2012)) //accident and modern car
                                    {
                                        montlyCarCoverageCost = liabilityRate + (liabilityRate * accidentRate) + modernCarFee;
                                    }
                                    else if ((CarInsuranceComboBox.SelectedIndex == 0) && (CarAccidentYesButton.Checked == true) && (clientAge < 25) && (carYear < 2012)) //accident and young
                                    {
                                        montlyCarCoverageCost = liabilityRate + (liabilityRate * accidentRate) + youngFee;
                                    }
                                    else if ((CarInsuranceComboBox.SelectedIndex == 0) && (CarAccidentYesButton.Checked == true) && (clientAge > 25) && (carYear < 2012)) //accident
                                    {
                                        montlyCarCoverageCost = liabilityRate + (liabilityRate * accidentRate);
                                    }
                                    else if ((CarInsuranceComboBox.SelectedIndex == 0) && (CarAccidentNoButton.Checked == true) && (clientAge < 25) && (carYear < 2012)) //young
                                    {
                                        montlyCarCoverageCost = liabilityRate + youngFee;
                                    }
                                    else if ((CarInsuranceComboBox.SelectedIndex == 0) && (CarAccidentNoButton.Checked == true) && (clientAge < 25) && (carYear > 2012)) //modern car
                                    {
                                        montlyCarCoverageCost = liabilityRate + modernCarFee;
                                    }
                                    else if ((CarInsuranceComboBox.SelectedIndex == 0) && (CarAccidentNoButton.Checked == true) && (clientAge > 25) && (carYear < 2012)) //no extra fees
                                    {
                                        montlyCarCoverageCost = liabilityRate;
                                    }
                       
                                    //full cover
                                    else if ((CarInsuranceComboBox.SelectedIndex == 1) && (CarAccidentYesButton.Checked == true) && (clientAge < 25) && (carYear > 2012)) //young with accident and modern car
                                    {
                                        montlyCarCoverageCost = fullRate + (fullRate * accidentRate) + youngFee + modernCarFee;
                                    }
                                    else if ((CarInsuranceComboBox.SelectedIndex == 1) && (CarAccidentNoButton.Checked == true) && (clientAge < 25) && (carYear > 2012)) //young with modern car
                                    {
                                        montlyCarCoverageCost = fullRate + youngFee + modernCarFee;
                                    }
                                    else if ((CarInsuranceComboBox.SelectedIndex == 1) && (CarAccidentYesButton.Checked == true) && (clientAge > 25) && (carYear > 2012)) //accident and modern car
                                    {
                                        montlyCarCoverageCost = fullRate + (fullRate * accidentRate) + modernCarFee;
                                    }
                                    else if ((CarInsuranceComboBox.SelectedIndex == 1) && (CarAccidentYesButton.Checked == true) && (clientAge < 25) && (carYear < 2012)) //accident and young
                                    {
                                        montlyCarCoverageCost =  fullRate + (fullRate * accidentRate) + youngFee;
                                    }
                                    else if ((CarInsuranceComboBox.SelectedIndex == 1) && (CarAccidentYesButton.Checked == true) && (clientAge > 25) && (carYear < 2012)) //accident
                                    {
                                        montlyCarCoverageCost = fullRate + (fullRate * accidentRate);
                                    }
                                    else if ((CarInsuranceComboBox.SelectedIndex == 1) && (CarAccidentNoButton.Checked == true) && (clientAge < 25) && (carYear < 2012)) //young
                                    {
                                        montlyCarCoverageCost = fullRate + youngFee;
                                    }
                                    else if ((CarInsuranceComboBox.SelectedIndex == 1) && (CarAccidentNoButton.Checked == true) && (clientAge < 25) && (carYear > 2012)) //modern car
                                    {
                                        montlyCarCoverageCost = fullRate + modernCarFee;
                                    }
                                    else if ((CarInsuranceComboBox.SelectedIndex == 1) && (CarAccidentNoButton.Checked == true) && (clientAge > 25) && (carYear < 2012)) //no extra fees
                                    {
                                        montlyCarCoverageCost = fullRate;
                                    }
                                    else if (CarInsuranceComboBox.SelectedIndex == 2) //no coverage selected
                                    {
                                        montlyCarCoverageCost = 0;
                                    }

                                    yearlyCarCoverageCost = montlyCarCoverageCost * year;       //calculate  yearly car insurance cost
                                    yearlyHealthCoverageCost = monthlyHealthCoverageCost * year;        //calculate yearly health insurance cost    
                                    yearlyPolicyTotal = yearlyCarCoverageCost + yearlyHealthCoverageCost;       //calculate total yearly policy cost
                                    HealthCoverageOutputLabel.Text = $"{yearlyHealthCoverageCost:C}";       //display yearly car insurance cost       
                                    CarCoverageOutputLabel.Text = $"{yearlyCarCoverageCost:C}";     //display yearly health insurance cost
                                    PolicyTotalOutputLabel.Text = $"{yearlyPolicyTotal:C}";     //display total yearly cost
                                }
                            }
                        }
                    }
                }
                else
                    MessageBox.Show("Invalid Manufacture Year Entered");
            }
            else
                MessageBox.Show("Invalid Age Entered");
        }
    }
}
