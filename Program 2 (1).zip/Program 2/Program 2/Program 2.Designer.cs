﻿
namespace Program_2
{
    partial class InsurancePolicyCalculator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TitleLabel = new System.Windows.Forms.Label();
            this.AgeLabel = new System.Windows.Forms.Label();
            this.ManufactureYearLabel = new System.Windows.Forms.Label();
            this.HealthInsuranceLabel = new System.Windows.Forms.Label();
            this.CarInsuranceLabel = new System.Windows.Forms.Label();
            this.SmokeLabel = new System.Windows.Forms.Label();
            this.SmokeGroupBox = new System.Windows.Forms.GroupBox();
            this.SmokeYesButton = new System.Windows.Forms.RadioButton();
            this.SmokeNoButton = new System.Windows.Forms.RadioButton();
            this.button1 = new System.Windows.Forms.Button();
            this.HealthCoverageCostLabel = new System.Windows.Forms.Label();
            this.CarCoverageCostLabel = new System.Windows.Forms.Label();
            this.TotalPolicyCostLabel = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.CarAccidentLabel = new System.Windows.Forms.Label();
            this.CarAccidentYesButton = new System.Windows.Forms.RadioButton();
            this.CarAccidentNoButton = new System.Windows.Forms.RadioButton();
            this.HealthCoverageOutputLabel = new System.Windows.Forms.Label();
            this.CarCoverageOutputLabel = new System.Windows.Forms.Label();
            this.PolicyTotalOutputLabel = new System.Windows.Forms.Label();
            this.AgeInputBox = new System.Windows.Forms.TextBox();
            this.ManufactureYearInputBox = new System.Windows.Forms.TextBox();
            this.HealthInsuranceComboBox = new System.Windows.Forms.ComboBox();
            this.CarInsuranceComboBox = new System.Windows.Forms.ComboBox();
            this.SmokeGroupBox.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // TitleLabel
            // 
            this.TitleLabel.AutoSize = true;
            this.TitleLabel.Location = new System.Drawing.Point(129, 25);
            this.TitleLabel.Name = "TitleLabel";
            this.TitleLabel.Size = new System.Drawing.Size(176, 13);
            this.TitleLabel.TabIndex = 0;
            this.TitleLabel.Text = "Cardinal Insurance Policy Calculator";
            this.TitleLabel.Click += new System.EventHandler(this.label1_Click);
            // 
            // AgeLabel
            // 
            this.AgeLabel.AutoSize = true;
            this.AgeLabel.Location = new System.Drawing.Point(88, 50);
            this.AgeLabel.Name = "AgeLabel";
            this.AgeLabel.Size = new System.Drawing.Size(82, 13);
            this.AgeLabel.TabIndex = 1;
            this.AgeLabel.Text = "Enter Your Age:";
            this.AgeLabel.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // ManufactureYearLabel
            // 
            this.ManufactureYearLabel.AutoSize = true;
            this.ManufactureYearLabel.Location = new System.Drawing.Point(88, 88);
            this.ManufactureYearLabel.Name = "ManufactureYearLabel";
            this.ManufactureYearLabel.Size = new System.Drawing.Size(126, 13);
            this.ManufactureYearLabel.TabIndex = 2;
            this.ManufactureYearLabel.Text = "Manufacture Year of Car:";
            // 
            // HealthInsuranceLabel
            // 
            this.HealthInsuranceLabel.AutoSize = true;
            this.HealthInsuranceLabel.Location = new System.Drawing.Point(88, 129);
            this.HealthInsuranceLabel.Name = "HealthInsuranceLabel";
            this.HealthInsuranceLabel.Size = new System.Drawing.Size(140, 13);
            this.HealthInsuranceLabel.TabIndex = 3;
            this.HealthInsuranceLabel.Text = "Health Insurance Coverage:";
            this.HealthInsuranceLabel.Click += new System.EventHandler(this.label3_Click);
            // 
            // CarInsuranceLabel
            // 
            this.CarInsuranceLabel.AutoSize = true;
            this.CarInsuranceLabel.Location = new System.Drawing.Point(88, 165);
            this.CarInsuranceLabel.Name = "CarInsuranceLabel";
            this.CarInsuranceLabel.Size = new System.Drawing.Size(125, 13);
            this.CarInsuranceLabel.TabIndex = 4;
            this.CarInsuranceLabel.Text = "Car Insurance Coverage:";
            this.CarInsuranceLabel.Click += new System.EventHandler(this.label4_Click);
            // 
            // SmokeLabel
            // 
            this.SmokeLabel.AutoSize = true;
            this.SmokeLabel.Location = new System.Drawing.Point(23, 25);
            this.SmokeLabel.Name = "SmokeLabel";
            this.SmokeLabel.Size = new System.Drawing.Size(85, 13);
            this.SmokeLabel.TabIndex = 5;
            this.SmokeLabel.Text = "Do You Smoke?";
            this.SmokeLabel.Click += new System.EventHandler(this.SmokeLabel_Click);
            // 
            // SmokeGroupBox
            // 
            this.SmokeGroupBox.Controls.Add(this.SmokeNoButton);
            this.SmokeGroupBox.Controls.Add(this.SmokeYesButton);
            this.SmokeGroupBox.Controls.Add(this.SmokeLabel);
            this.SmokeGroupBox.Location = new System.Drawing.Point(91, 214);
            this.SmokeGroupBox.Name = "SmokeGroupBox";
            this.SmokeGroupBox.Size = new System.Drawing.Size(331, 87);
            this.SmokeGroupBox.TabIndex = 6;
            this.SmokeGroupBox.TabStop = false;
            this.SmokeGroupBox.Enter += new System.EventHandler(this.SmokeGroupBox_Enter);
            // 
            // SmokeYesButton
            // 
            this.SmokeYesButton.AutoSize = true;
            this.SmokeYesButton.Location = new System.Drawing.Point(229, 19);
            this.SmokeYesButton.Name = "SmokeYesButton";
            this.SmokeYesButton.Size = new System.Drawing.Size(43, 17);
            this.SmokeYesButton.TabIndex = 6;
            this.SmokeYesButton.TabStop = true;
            this.SmokeYesButton.Text = "Yes";
            this.SmokeYesButton.UseVisualStyleBackColor = true;
            this.SmokeYesButton.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // SmokeNoButton
            // 
            this.SmokeNoButton.AutoSize = true;
            this.SmokeNoButton.Location = new System.Drawing.Point(229, 51);
            this.SmokeNoButton.Name = "SmokeNoButton";
            this.SmokeNoButton.Size = new System.Drawing.Size(39, 17);
            this.SmokeNoButton.TabIndex = 7;
            this.SmokeNoButton.TabStop = true;
            this.SmokeNoButton.Text = "No";
            this.SmokeNoButton.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(169, 400);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(175, 28);
            this.button1.TabIndex = 7;
            this.button1.Text = "Calculate Policy Premiums";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // HealthCoverageCostLabel
            // 
            this.HealthCoverageCostLabel.AutoSize = true;
            this.HealthCoverageCostLabel.Location = new System.Drawing.Point(81, 452);
            this.HealthCoverageCostLabel.Name = "HealthCoverageCostLabel";
            this.HealthCoverageCostLabel.Size = new System.Drawing.Size(157, 13);
            this.HealthCoverageCostLabel.TabIndex = 8;
            this.HealthCoverageCostLabel.Text = "Health Coverage Cost per Year:";
            // 
            // CarCoverageCostLabel
            // 
            this.CarCoverageCostLabel.AutoSize = true;
            this.CarCoverageCostLabel.Location = new System.Drawing.Point(81, 482);
            this.CarCoverageCostLabel.Name = "CarCoverageCostLabel";
            this.CarCoverageCostLabel.Size = new System.Drawing.Size(142, 13);
            this.CarCoverageCostLabel.TabIndex = 9;
            this.CarCoverageCostLabel.Text = "Car Coverage Cost per Year:";
            // 
            // TotalPolicyCostLabel
            // 
            this.TotalPolicyCostLabel.AutoSize = true;
            this.TotalPolicyCostLabel.Location = new System.Drawing.Point(81, 512);
            this.TotalPolicyCostLabel.Name = "TotalPolicyCostLabel";
            this.TotalPolicyCostLabel.Size = new System.Drawing.Size(132, 13);
            this.TotalPolicyCostLabel.TabIndex = 10;
            this.TotalPolicyCostLabel.Text = "Total Policy Cost per Year:";
            this.TotalPolicyCostLabel.Click += new System.EventHandler(this.TotalPolicyCostLabel_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.CarAccidentNoButton);
            this.groupBox1.Controls.Add(this.CarAccidentYesButton);
            this.groupBox1.Controls.Add(this.CarAccidentLabel);
            this.groupBox1.Location = new System.Drawing.Point(91, 307);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(331, 87);
            this.groupBox1.TabIndex = 11;
            this.groupBox1.TabStop = false;
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // CarAccidentLabel
            // 
            this.CarAccidentLabel.AutoSize = true;
            this.CarAccidentLabel.Location = new System.Drawing.Point(23, 37);
            this.CarAccidentLabel.Name = "CarAccidentLabel";
            this.CarAccidentLabel.Size = new System.Drawing.Size(152, 13);
            this.CarAccidentLabel.TabIndex = 2;
            this.CarAccidentLabel.Text = "Car Accident in the Past Year?";
            this.CarAccidentLabel.Click += new System.EventHandler(this.label1_Click_2);
            // 
            // CarAccidentYesButton
            // 
            this.CarAccidentYesButton.AutoSize = true;
            this.CarAccidentYesButton.Location = new System.Drawing.Point(229, 19);
            this.CarAccidentYesButton.Name = "CarAccidentYesButton";
            this.CarAccidentYesButton.Size = new System.Drawing.Size(43, 17);
            this.CarAccidentYesButton.TabIndex = 3;
            this.CarAccidentYesButton.TabStop = true;
            this.CarAccidentYesButton.Text = "Yes";
            this.CarAccidentYesButton.UseVisualStyleBackColor = true;
            this.CarAccidentYesButton.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged_1);
            // 
            // CarAccidentNoButton
            // 
            this.CarAccidentNoButton.AutoSize = true;
            this.CarAccidentNoButton.Location = new System.Drawing.Point(229, 51);
            this.CarAccidentNoButton.Name = "CarAccidentNoButton";
            this.CarAccidentNoButton.Size = new System.Drawing.Size(39, 17);
            this.CarAccidentNoButton.TabIndex = 4;
            this.CarAccidentNoButton.TabStop = true;
            this.CarAccidentNoButton.Text = "No";
            this.CarAccidentNoButton.UseVisualStyleBackColor = true;
            // 
            // HealthCoverageOutputLabel
            // 
            this.HealthCoverageOutputLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.HealthCoverageOutputLabel.Location = new System.Drawing.Point(279, 451);
            this.HealthCoverageOutputLabel.Name = "HealthCoverageOutputLabel";
            this.HealthCoverageOutputLabel.Size = new System.Drawing.Size(95, 19);
            this.HealthCoverageOutputLabel.TabIndex = 12;
            this.HealthCoverageOutputLabel.Click += new System.EventHandler(this.label1_Click_3);
            // 
            // CarCoverageOutputLabel
            // 
            this.CarCoverageOutputLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.CarCoverageOutputLabel.Location = new System.Drawing.Point(279, 481);
            this.CarCoverageOutputLabel.Name = "CarCoverageOutputLabel";
            this.CarCoverageOutputLabel.Size = new System.Drawing.Size(95, 20);
            this.CarCoverageOutputLabel.TabIndex = 13;
            this.CarCoverageOutputLabel.Click += new System.EventHandler(this.label1_Click_4);
            // 
            // PolicyTotalOutputLabel
            // 
            this.PolicyTotalOutputLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PolicyTotalOutputLabel.Location = new System.Drawing.Point(279, 511);
            this.PolicyTotalOutputLabel.Name = "PolicyTotalOutputLabel";
            this.PolicyTotalOutputLabel.Size = new System.Drawing.Size(95, 22);
            this.PolicyTotalOutputLabel.TabIndex = 14;
            // 
            // AgeInputBox
            // 
            this.AgeInputBox.Location = new System.Drawing.Point(322, 50);
            this.AgeInputBox.Name = "AgeInputBox";
            this.AgeInputBox.Size = new System.Drawing.Size(100, 20);
            this.AgeInputBox.TabIndex = 15;
            // 
            // ManufactureYearInputBox
            // 
            this.ManufactureYearInputBox.Location = new System.Drawing.Point(322, 88);
            this.ManufactureYearInputBox.Name = "ManufactureYearInputBox";
            this.ManufactureYearInputBox.Size = new System.Drawing.Size(100, 20);
            this.ManufactureYearInputBox.TabIndex = 16;
            // 
            // HealthInsuranceComboBox
            // 
            this.HealthInsuranceComboBox.FormattingEnabled = true;
            this.HealthInsuranceComboBox.Items.AddRange(new object[] {
            "EPO",
            "PPO",
            "HDP",
            "None"});
            this.HealthInsuranceComboBox.Location = new System.Drawing.Point(301, 129);
            this.HealthInsuranceComboBox.Name = "HealthInsuranceComboBox";
            this.HealthInsuranceComboBox.Size = new System.Drawing.Size(121, 21);
            this.HealthInsuranceComboBox.TabIndex = 17;
            // 
            // CarInsuranceComboBox
            // 
            this.CarInsuranceComboBox.FormattingEnabled = true;
            this.CarInsuranceComboBox.Items.AddRange(new object[] {
            "Liability",
            "Full ",
            "None"});
            this.CarInsuranceComboBox.Location = new System.Drawing.Point(301, 162);
            this.CarInsuranceComboBox.Name = "CarInsuranceComboBox";
            this.CarInsuranceComboBox.Size = new System.Drawing.Size(121, 21);
            this.CarInsuranceComboBox.TabIndex = 18;
            // 
            // InsurancePolicyCalculator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(434, 561);
            this.Controls.Add(this.CarInsuranceComboBox);
            this.Controls.Add(this.HealthInsuranceComboBox);
            this.Controls.Add(this.ManufactureYearInputBox);
            this.Controls.Add(this.AgeInputBox);
            this.Controls.Add(this.PolicyTotalOutputLabel);
            this.Controls.Add(this.CarCoverageOutputLabel);
            this.Controls.Add(this.HealthCoverageOutputLabel);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.TotalPolicyCostLabel);
            this.Controls.Add(this.CarCoverageCostLabel);
            this.Controls.Add(this.HealthCoverageCostLabel);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.SmokeGroupBox);
            this.Controls.Add(this.CarInsuranceLabel);
            this.Controls.Add(this.HealthInsuranceLabel);
            this.Controls.Add(this.ManufactureYearLabel);
            this.Controls.Add(this.AgeLabel);
            this.Controls.Add(this.TitleLabel);
            this.Name = "InsurancePolicyCalculator";
            this.Text = "Insurance Policy Calculator";
            this.Load += new System.EventHandler(this.InsurancePolicyCalculator_Load);
            this.SmokeGroupBox.ResumeLayout(false);
            this.SmokeGroupBox.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label TitleLabel;
        private System.Windows.Forms.Label AgeLabel;
        private System.Windows.Forms.Label ManufactureYearLabel;
        private System.Windows.Forms.Label HealthInsuranceLabel;
        private System.Windows.Forms.Label CarInsuranceLabel;
        private System.Windows.Forms.Label SmokeLabel;
        private System.Windows.Forms.GroupBox SmokeGroupBox;
        private System.Windows.Forms.RadioButton SmokeYesButton;
        private System.Windows.Forms.RadioButton SmokeNoButton;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label HealthCoverageCostLabel;
        private System.Windows.Forms.Label CarCoverageCostLabel;
        private System.Windows.Forms.Label TotalPolicyCostLabel;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label CarAccidentLabel;
        private System.Windows.Forms.RadioButton CarAccidentYesButton;
        private System.Windows.Forms.Label HealthCoverageOutputLabel;
        private System.Windows.Forms.RadioButton CarAccidentNoButton;
        private System.Windows.Forms.Label CarCoverageOutputLabel;
        private System.Windows.Forms.Label PolicyTotalOutputLabel;
        private System.Windows.Forms.TextBox AgeInputBox;
        private System.Windows.Forms.TextBox ManufactureYearInputBox;
        private System.Windows.Forms.ComboBox HealthInsuranceComboBox;
        private System.Windows.Forms.ComboBox CarInsuranceComboBox;
    }
}

